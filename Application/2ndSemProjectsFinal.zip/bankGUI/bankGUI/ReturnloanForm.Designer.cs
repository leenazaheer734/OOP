﻿
namespace bankGUI
{
    partial class ReturnloanForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.r_lbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.amountTB = new Guna.UI2.WinForms.Guna2TextBox();
            this.money_lbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.wBTN = new Guna.UI2.WinForms.Guna2Button();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(44)))), ((int)(((byte)(141)))));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(236, 28);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(195, 34);
            this.guna2HtmlLabel1.TabIndex = 20;
            this.guna2HtmlLabel1.Text = "Amount Withdrawl";
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.guna2CustomGradientPanel1.BorderRadius = 30;
            this.guna2CustomGradientPanel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            this.guna2CustomGradientPanel1.BorderThickness = 7;
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2CustomGradientPanel1.Controls.Add(this.r_lbl);
            this.guna2CustomGradientPanel1.Controls.Add(this.amountTB);
            this.guna2CustomGradientPanel1.Controls.Add(this.money_lbl);
            this.guna2CustomGradientPanel1.FillColor = System.Drawing.Color.DarkGray;
            this.guna2CustomGradientPanel1.FillColor2 = System.Drawing.SystemColors.MenuHighlight;
            this.guna2CustomGradientPanel1.FillColor3 = System.Drawing.Color.RoyalBlue;
            this.guna2CustomGradientPanel1.FillColor4 = System.Drawing.Color.SkyBlue;
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(100, 114);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(501, 157);
            this.guna2CustomGradientPanel1.TabIndex = 22;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Zilla Slab SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(110, 101);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(156, 27);
            this.guna2HtmlLabel3.TabIndex = 19;
            this.guna2HtmlLabel3.Text = "Remaining Loan: ";
            // 
            // r_lbl
            // 
            this.r_lbl.BackColor = System.Drawing.Color.White;
            this.r_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r_lbl.Font = new System.Drawing.Font("Zilla Slab SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(141)))));
            this.r_lbl.Location = new System.Drawing.Point(272, 101);
            this.r_lbl.Name = "r_lbl";
            this.r_lbl.Size = new System.Drawing.Size(16, 27);
            this.r_lbl.TabIndex = 18;
            this.r_lbl.Text = "0";
            // 
            // amountTB
            // 
            this.amountTB.BackColor = System.Drawing.Color.Transparent;
            this.amountTB.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.amountTB.BorderRadius = 7;
            this.amountTB.BorderThickness = 5;
            this.amountTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.amountTB.DefaultText = "";
            this.amountTB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.amountTB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.amountTB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.amountTB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.amountTB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.amountTB.Font = new System.Drawing.Font("Zilla Slab", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amountTB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(44)))), ((int)(((byte)(141)))));
            this.amountTB.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.amountTB.Location = new System.Drawing.Point(314, 30);
            this.amountTB.Margin = new System.Windows.Forms.Padding(12);
            this.amountTB.Name = "amountTB";
            this.amountTB.PasswordChar = '\0';
            this.amountTB.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(44)))), ((int)(((byte)(141)))));
            this.amountTB.PlaceholderText = "";
            this.amountTB.SelectedText = "";
            this.amountTB.Size = new System.Drawing.Size(154, 44);
            this.amountTB.TabIndex = 17;
            // 
            // money_lbl
            // 
            this.money_lbl.BackColor = System.Drawing.Color.Transparent;
            this.money_lbl.Font = new System.Drawing.Font("Zilla Slab SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.money_lbl.ForeColor = System.Drawing.Color.White;
            this.money_lbl.Location = new System.Drawing.Point(17, 36);
            this.money_lbl.Name = "money_lbl";
            this.money_lbl.Size = new System.Drawing.Size(282, 27);
            this.money_lbl.TabIndex = 16;
            this.money_lbl.Text = "Enter Amount You Are Paying: ";
            // 
            // wBTN
            // 
            this.wBTN.BorderRadius = 14;
            this.wBTN.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.wBTN.BorderThickness = 2;
            this.wBTN.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.wBTN.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.wBTN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.wBTN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.wBTN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(141)))));
            this.wBTN.Font = new System.Drawing.Font("Zilla Slab", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wBTN.ForeColor = System.Drawing.Color.White;
            this.wBTN.Location = new System.Drawing.Point(300, 310);
            this.wBTN.Name = "wBTN";
            this.wBTN.Size = new System.Drawing.Size(153, 38);
            this.wBTN.TabIndex = 23;
            this.wBTN.Text = "Return";
            this.wBTN.Click += new System.EventHandler(this.wBTN_Click);
            // 
            // ReturnloanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.Controls.Add(this.wBTN);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Name = "ReturnloanForm";
            this.Size = new System.Drawing.Size(697, 433);
            this.Load += new System.EventHandler(this.ReturnloanForm_Load);
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.guna2CustomGradientPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2TextBox amountTB;
        private Guna.UI2.WinForms.Guna2HtmlLabel money_lbl;
        private Guna.UI2.WinForms.Guna2Button wBTN;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel r_lbl;
    }
}
