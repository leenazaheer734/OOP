﻿
namespace bankGUI
{
    partial class TransferForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.recpAMOUNT_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.recpNAME_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.recpACCNUM_tb = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.money_lbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.transfer_BTN = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(44)))), ((int)(((byte)(141)))));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(251, 27);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(159, 34);
            this.guna2HtmlLabel1.TabIndex = 20;
            this.guna2HtmlLabel1.Text = "Money Transfer";
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.guna2Panel1.BorderRadius = 25;
            this.guna2Panel1.BorderThickness = 2;
            this.guna2Panel1.Controls.Add(this.recpAMOUNT_tb);
            this.guna2Panel1.Controls.Add(this.recpNAME_tb);
            this.guna2Panel1.Controls.Add(this.recpACCNUM_tb);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2Panel1.Controls.Add(this.money_lbl);
            this.guna2Panel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2Panel1.Location = new System.Drawing.Point(40, 123);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(610, 207);
            this.guna2Panel1.TabIndex = 21;
            // 
            // recpAMOUNT_tb
            // 
            this.recpAMOUNT_tb.BorderColor = System.Drawing.Color.CadetBlue;
            this.recpAMOUNT_tb.BorderRadius = 4;
            this.recpAMOUNT_tb.BorderThickness = 3;
            this.recpAMOUNT_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.recpAMOUNT_tb.DefaultText = "";
            this.recpAMOUNT_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.recpAMOUNT_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.recpAMOUNT_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.recpAMOUNT_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.recpAMOUNT_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.recpAMOUNT_tb.Font = new System.Drawing.Font("Zilla Slab SemiBold", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recpAMOUNT_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.recpAMOUNT_tb.Location = new System.Drawing.Point(322, 141);
            this.recpAMOUNT_tb.Name = "recpAMOUNT_tb";
            this.recpAMOUNT_tb.PasswordChar = '\0';
            this.recpAMOUNT_tb.PlaceholderText = "";
            this.recpAMOUNT_tb.SelectedText = "";
            this.recpAMOUNT_tb.Size = new System.Drawing.Size(223, 34);
            this.recpAMOUNT_tb.TabIndex = 22;
            // 
            // recpNAME_tb
            // 
            this.recpNAME_tb.BorderColor = System.Drawing.Color.CadetBlue;
            this.recpNAME_tb.BorderRadius = 4;
            this.recpNAME_tb.BorderThickness = 3;
            this.recpNAME_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.recpNAME_tb.DefaultText = "";
            this.recpNAME_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.recpNAME_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.recpNAME_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.recpNAME_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.recpNAME_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.recpNAME_tb.Font = new System.Drawing.Font("Zilla Slab SemiBold", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recpNAME_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.recpNAME_tb.Location = new System.Drawing.Point(322, 88);
            this.recpNAME_tb.Name = "recpNAME_tb";
            this.recpNAME_tb.PasswordChar = '\0';
            this.recpNAME_tb.PlaceholderText = "";
            this.recpNAME_tb.SelectedText = "";
            this.recpNAME_tb.Size = new System.Drawing.Size(223, 34);
            this.recpNAME_tb.TabIndex = 21;
            // 
            // recpACCNUM_tb
            // 
            this.recpACCNUM_tb.BorderColor = System.Drawing.Color.CadetBlue;
            this.recpACCNUM_tb.BorderRadius = 4;
            this.recpACCNUM_tb.BorderThickness = 3;
            this.recpACCNUM_tb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.recpACCNUM_tb.DefaultText = "";
            this.recpACCNUM_tb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.recpACCNUM_tb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.recpACCNUM_tb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.recpACCNUM_tb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.recpACCNUM_tb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.recpACCNUM_tb.Font = new System.Drawing.Font("Zilla Slab SemiBold", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recpACCNUM_tb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.recpACCNUM_tb.Location = new System.Drawing.Point(322, 42);
            this.recpACCNUM_tb.Name = "recpACCNUM_tb";
            this.recpACCNUM_tb.PasswordChar = '\0';
            this.recpACCNUM_tb.PlaceholderText = "";
            this.recpACCNUM_tb.SelectedText = "";
            this.recpACCNUM_tb.Size = new System.Drawing.Size(223, 34);
            this.recpACCNUM_tb.TabIndex = 20;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Zilla Slab SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(141)))));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(112, 148);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(194, 27);
            this.guna2HtmlLabel3.TabIndex = 19;
            this.guna2HtmlLabel3.Text = "Amount To Transfer: ";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Zilla Slab SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(141)))));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(37, 46);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(269, 27);
            this.guna2HtmlLabel2.TabIndex = 18;
            this.guna2HtmlLabel2.Text = "Recipient\'s Account Number: ";
            // 
            // money_lbl
            // 
            this.money_lbl.BackColor = System.Drawing.Color.Transparent;
            this.money_lbl.Font = new System.Drawing.Font("Zilla Slab SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.money_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(141)))));
            this.money_lbl.Location = new System.Drawing.Point(140, 95);
            this.money_lbl.Name = "money_lbl";
            this.money_lbl.Size = new System.Drawing.Size(166, 27);
            this.money_lbl.TabIndex = 17;
            this.money_lbl.Text = "Recipient\'s Name: ";
            // 
            // transfer_BTN
            // 
            this.transfer_BTN.BorderRadius = 14;
            this.transfer_BTN.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.transfer_BTN.BorderThickness = 2;
            this.transfer_BTN.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.transfer_BTN.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.transfer_BTN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.transfer_BTN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.transfer_BTN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(49)))), ((int)(((byte)(141)))));
            this.transfer_BTN.Font = new System.Drawing.Font("Zilla Slab", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transfer_BTN.ForeColor = System.Drawing.Color.White;
            this.transfer_BTN.Location = new System.Drawing.Point(471, 362);
            this.transfer_BTN.Name = "transfer_BTN";
            this.transfer_BTN.Size = new System.Drawing.Size(153, 38);
            this.transfer_BTN.TabIndex = 23;
            this.transfer_BTN.Text = "Transfer";
            this.transfer_BTN.Click += new System.EventHandler(this.transfer_BTN_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.BackgroundImage = global::bankGUI.Properties.Resources.My_project;
            this.guna2PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(480, 15);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(157, 82);
            this.guna2PictureBox1.TabIndex = 24;
            this.guna2PictureBox1.TabStop = false;
            // 
            // TransferForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.transfer_BTN);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Name = "TransferForm";
            this.Size = new System.Drawing.Size(693, 429);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Button transfer_BTN;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel money_lbl;
        private Guna.UI2.WinForms.Guna2TextBox recpAMOUNT_tb;
        private Guna.UI2.WinForms.Guna2TextBox recpNAME_tb;
        private Guna.UI2.WinForms.Guna2TextBox recpACCNUM_tb;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
    }
}
