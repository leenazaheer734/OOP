﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bankGUI.DL;
using bankGUI.BL;

namespace bankGUI
{
    public partial class DepositAmount : UserControl
    {
        public DepositAmount()
        {
            InitializeComponent();
        }

        private void wBTN_Click(object sender, EventArgs e)
        {
            double damount = double.Parse(amountTB.Text.ToString());
            
            if (TransDL.checkStatusOfAccount(ExtraDL.CurrentClient))
            {
                TransDL.addMoneyInAccount(damount, ExtraDL.CurrentClient);
                DateTime date = DateTime.Now;
                Transaction t = new Transaction(ExtraDL.CurrentClient, damount, date, "withdraw");

                TransDL.AddTransactionInList(t);
                TransDL.StoreTransactionInFile(t);
                ClientDL.UpdateClientDataInFile();
                MessageBox.Show("Transaction Successfull");
            }
            else
            {
                MessageBox.Show("Your Account is blocked you cannot withdraw money");
            }
            amountTB.Text = null;
        }
    }
}
