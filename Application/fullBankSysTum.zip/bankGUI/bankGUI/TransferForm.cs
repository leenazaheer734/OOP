﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bankGUI.BL;
using bankGUI.DL;

namespace bankGUI
{
    public partial class TransferForm : UserControl
    {
        public TransferForm()
        {
            InitializeComponent();
        }

        private void transfer_BTN_Click(object sender, EventArgs e)
        {
            if (TransDL.checkStatusOfAccount(ExtraDL.CurrentClient))
            {
                Transaction t = transferMoney(ExtraDL.CurrentClient);
                if (t != null)
                {
                    TransDL.AddTransactionInList(t);
                    ClientDL.UpdateClientDataInFile();
                    TransDL.StoreTransactionInFile(t);
                    MessageBox.Show("Transferred Succesfully");
                }
                else
                {
                    MessageBox.Show("Account Not Found");
                }
            }
            else
            {
                MessageBox.Show("Money cannot be transferred! Your account is blocked!");
            }
            recpACCNUM_tb.Text = null;
            recpAMOUNT_tb.Text = null;
            recpNAME_tb.Text = null;
        }

        private Transaction transferMoney(Client c)
        {
            string name = recpNAME_tb.Text.ToString();
            int accountnum = int.Parse(recpACCNUM_tb.Text);
            double amount = double.Parse(recpAMOUNT_tb.Text);

            Account a = new Account(accountnum);
            Person p = new Person(name);
            Client c1 = new Client(p, a);
            c1 = ClientDL.SearchClientAccount(c1);        //checking if recipient's account exists
            if (c1 != null)
            {
                string transfeeAccount = c1.Account.AccountNumber.ToString();

                TransDL.addMoneyInAccount(amount, c1);     //addming money in recipient's account
                TransDL.minusMoneyFromAccount(amount, c);   //subtracting from sender's account

                Transaction t = new Transaction(c, amount, DateTime.Now, "transfer", transfeeAccount);
                return t;
            }
            else
            {
                return null;
            }
        }
    }
}
