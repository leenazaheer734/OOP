﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bankGUI.BL;
using bankGUI.DL;

namespace bankGUI
{
    public partial class DoUpdate : UserControl
    {
        private int updatingAccount;
        public DoUpdate()
        {
            InitializeComponent();
        }

        public int UpdatingAccount { get => updatingAccount; set => updatingAccount = value; }

        private void srchBTN_Click(object sender, EventArgs e)
        {
            Client d =  ClientDL.seacrhwithACCnumber(updatingAccount);   //searching a user's details
            if (d != null)
            {
                d.ClientCred.Phonenumber = contactTB.Text.ToString(); 
                d.ClientCred.Password = passwordTB.Text.ToString();
                d.Account.Status = statusTB.Text.ToString();
                d.Account.Type = acctypeTB.Text.ToString();

                ClientDL.UpdateClientDataInFile();
            }
            MessageBox.Show("Updated");
            Controls.Clear();
            UpdateClientInfo update = new UpdateClientInfo();
            this.Controls.Add(update);
            update.Visible = true;
        }
    }
}
