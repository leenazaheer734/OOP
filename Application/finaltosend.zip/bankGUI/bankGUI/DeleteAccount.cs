﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bankGUI.BL;
using bankGUI.DL;

namespace bankGUI
{
    public partial class DeleteAccount : UserControl
    {
        public DeleteAccount()
        {
            InitializeComponent();
        }

        private void DeleteAccount_Load(object sender, EventArgs e)
        {
            dataBind();
        }

        private void dataBind()
        {
            clientsGV.DataSource = null;
            foreach (var o in ClientDL.getClientList())
            {
                clientsGV.DataSource = ClientDL.getClientList().Select(c => new { c.Account.AccountNumber,c.ClientCred.Username, c.ClientCred.Phonenumber,c.Account.Balance, c.Account.Status, c.Account.Type }).ToList();
            }
            // yield
            clientsGV.Refresh();
        }

        public void delBTN_Click(object sender, EventArgs e)
        {
            string name = cnameTB.Text;
            int accno = int.Parse(accNumTB.Text);

            Person p = new Person(name);
            Account a = new Account(accno);
            Client c = new Client(p, a);
            bool check = ClientDL.CheckifClientExixts(c);
            if (check == true)
            {
                AdminDL.Account_close(c);
                ClientDL.UpdateClientDataInFile();
                dataBind();
            }
            else
            {
                MessageBox.Show("Account not Found");
            }
            cnameTB.Text = null;
            accNumTB.Text = null;
        }

      
    }
}
