﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bankGUI.BL;
using bankGUI.DL;

namespace bankGUI
{
    public partial class ViewAccounts : UserControl
    {
        public ViewAccounts()
        {
            InitializeComponent();
        }
    
        private void ViewAccounts_Load(object sender, EventArgs e)
        {
            dataBind();
        }

        private void dataBind()
        {
            clientsGV.DataSource = null;
            foreach (var o in ClientDL.getClientList())
            {
                clientsGV.DataSource = ClientDL.getClientList().Select(c => new { c.Account.AccountNumber, c.ClientCred.Username, c.ClientCred.Phonenumber, c.Account.Balance, c.Account.Status, c.Account.Type }).ToList();
            }
            // yield
            clientsGV.Refresh();
        }

/*        private void SearchClient(string searchTerm)
        {
            // Get the client list from your data source (e.g., ClientDL.getClientList())
            List<Client> clientList = ClientDL.getClientList();

            // Filter the client list based on the search term
            List<Client> filteredList = clientList.Where(c => c.Account.AccountNumber.ToString().Contains(searchTerm)).ToList();

            // Convert the filtered list to a BindingList
            BindingList<Client> bindingList = new BindingList<Client>(filteredList);

            // Clear the DataGridView rows
            clientsGV.DataSource = null;

            // Set the BindingList as the DataSource for the DataGridView
            clientsGV.DataSource = bindingList;

          *//*  if (clientsGV.Columns.Count > 0)
            {
                // Check if the desired column exists
                if (clientsGV.Columns.Contains("AccountNumber"))
                {
                    // Sort the DataGridView by the "AccountNumber" column
                    clientsGV.Sort(clientsGV.Columns["AccountNumber"], ListSortDirection.Ascending);
                }
            }*//*
        }*/
      
        private void SearchClient(string searchTerm)
        {
            // Get the client list from your data source (e.g., ClientDL.getClientList())
            List<Client> clientList = ClientDL.getClientList();

            // Filter the client list based on the search term
            List<Client> filteredList = clientList.Where(c => c.Account.AccountNumber.ToString().Contains(searchTerm)).ToList();

            // Convert the filtered list to a BindingList
            BindingList<Client> bindingList = new BindingList<Client>(filteredList);

            // Clear the DataGridView rows
            clientsGV.DataSource = null;

            // Set the BindingList as the DataSource for the DataGridView
            clientsGV.DataSource = bindingList;

            // Select the matching row
            if (clientsGV.Rows.Count > 0)
            {
                string accountNumberColumnName = clientsGV.Columns[0].Name; // Assuming AccountNumber is the first column

                DataGridViewRow matchingRow = clientsGV.Rows.Cast<DataGridViewRow>().FirstOrDefault(row => row.Cells[accountNumberColumnName].Value.ToString().Contains(searchTerm));

                if (matchingRow != null)
                {
                    matchingRow.Selected = true;
                    clientsGV.CurrentCell = matchingRow.Cells[accountNumberColumnName];
                }
            }
        }

        private void srchBTN_Click(object sender, EventArgs e)
        {
            string text = accNumTB.Text;
            SearchClient(text);
        }

   
    }
}
