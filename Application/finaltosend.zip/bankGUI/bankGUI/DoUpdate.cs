﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankGUI
{
    public partial class DoUpdate : UserControl
    {
        public DoUpdate()
        {
            InitializeComponent();
        }

        private void srchBTN_Click(object sender, EventArgs e)
        {
            Controls.Clear();
            UpdateClientInfo update = new UpdateClientInfo();
            this.Controls.Add(update);
            update.Visible = true;
        }
    }
}
