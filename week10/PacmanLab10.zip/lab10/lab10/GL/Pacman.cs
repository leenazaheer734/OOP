﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab10.GL
{
    class Pacman : GameObject
    {
        public Pacman(GameCell c, char display) : base(display)
        {
            base.currentCell = c;
        }

        public void move(GameDirection gd)
        {
          //  char currentcharacter = base..currentGameObject.displayCharacter;
        }
    }
}
