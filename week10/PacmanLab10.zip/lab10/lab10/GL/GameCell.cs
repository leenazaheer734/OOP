﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab10.GL
{
    class GameCell
    {
        public int x;
        public int y;
        public GameObject currentGameObject;
        public GameGrid gameGrid;

        public GameCell(int x, int y, GameGrid g)
        {
            this.x = x;
            this.y = y;
            this.gameGrid = g;
        }
        public GameCell NextCell(GameDirection d)
        {
            if( d == GameDirection.UP)
            {
                return gameGrid.getCell(x - 1, y);
            }
            else if (d == GameDirection.DOWN)
            {
                return gameGrid.getCell(x + 1, y);
            }
            else if(d == GameDirection.RIGHT)
            {
                return gameGrid.getCell(x, y + 1);
            }
            else 
            {
                return gameGrid.getCell(x, y - 1);
            }
        }
    }
}
